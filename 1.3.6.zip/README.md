# 神奇的密码

一款本地运行、注重隐私与安全的密码管理 Android 应用（Material 3 风格）。

## ✨ 功能特性

- 🔐 **本地加密存储**：密码数据全部保存在本地，使用 PBKDF2 + 100,000 次迭代的主密码加密，不上传任何隐私
- 🔓 **双解锁方式**：支持应用主密码 / 手机系统锁屏密码二选一
- 🔍 **密码管理**：增删改查、搜索、置顶、批量删除、拖动排序
- 📦 **导入导出**：AES-GCM 加密备份
- 📱 **一键联网更新**：检查更新、实时显示下载进度/网速/文件大小、自动安装
- 🎨 **主题定制**：6 种预选主题色 + RGB 自定义，渐变开屏动画与打字机效果
- 🖼️ 背景图片自定义（选图、裁剪、透明度调节）

## 🛠️ 技术栈

- Android（Java）
- Material 3
- SQLite（Room 风格 Helper）
- 无任何第三方网络库，检查更新/下载用系统 `HttpURLConnection`

## 📦 构建

本项目使用 **CodeAssist** 构建，配置文件为 `app/module.toml`。

- minSdk 26 / targetSdk 34
- 构建命令：在 CodeAssist 中点击构建（release / debug）

## 📂 项目结构

```
app/src/main/java/com/bzsx/password/
├── SplashActivity.java        # 开屏动画
├── LockScreenActivity.java     # 锁屏/解锁/系统锁屏验证/忘记密码
├── MainActivity.java           # 主界面
├── SettingsFragment.java       # 关于页/设置/联系作者
├── PasswordListFragment.java   # 密码列表
├── DatabaseHelper.java         # 数据库
├── CryptoUtil.java             # 加密
├── SessionManager.java         # 会话/主密码缓存
└── ...
```

## 👤 关于作者

**宝藏水仙**

- B站：[space.bilibili.com/3546612747995937](https://space.bilibili.com/3546612747995937)
- 官方网站：https://bzsx.lhx520.icu/password.html

## 📄 License

本项目代码仅供学习交流使用，禁止商用，禁止倒卖。完整声明见应用内"首次使用验证"说明。
